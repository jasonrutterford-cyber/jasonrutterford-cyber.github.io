# AI Brief Builder

A one-page-of-text agent that interviews the person asking for an AI agent and writes the brief a leader can sign off and a team can build from. Takes about an hour of the expert's time. Works in whichever tool they already use.

From the article "You've signed off an AI project. Did anyone ask what problem it solves?" — https://jasonrutterford-cyber.github.io/writing/did-anyone-ask-what-problem-it-solves/

## Use it in Claude
Upload the whole `ai-brief-builder` folder as a skill (Settings → Capabilities → Skills), or in a Claude Project paste `SKILL.md` into the project instructions. Then say: "Run the AI brief builder. I want an agent that..."

## Use it in ChatGPT
Create a custom GPT (Explore GPTs → Create). Paste the text from `instructions-for-copilot-and-chatgpt.md` into Instructions. Name it "AI Brief Builder". Start a chat and describe the agent you want.

## Use it in Microsoft Copilot
In M365 Copilot choose "Create an agent" (or open Copilot Studio). Paste the same text into the agent's instructions. Share it with the people who bring you AI requests.

## What you get
A brief in a fixed shape: the one line, the real problem, a recommendation (build / build narrower / fix the underlying problem / this does not need an agent), what it does, what it touches, the rules, what happens when it goes wrong, how you will know it works, and job stories for the team. `example-brief.md` shows one end to end.

## Where it comes from
The questions are the Agent Empathy Canvas, reframed for the person who signs the budget: https://jasonrutterford-cyber.github.io/writing/we-used-to-design-for-humans/

Free to use and adapt. If you improve it, I'd like to hear how: jason.rutterford@gmail.com
